/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project_TRPL;

import controller.c_login;

/**
 *
 * @author bedhu
 */
public class Project_TRPL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new c_login();
    }

}
