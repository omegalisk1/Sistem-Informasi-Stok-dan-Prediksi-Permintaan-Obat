/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.m_histori;
import model.m_stok;
import model.m_permintaan;
import org.jfree.data.time.Month;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import view.v_prediksi;

/**
 *
 * @author bedhu
 */
public class c_prediksi {

    private v_prediksi view;
    private m_histori modelH;
    private m_stok modelO;
    private m_permintaan modelP;
    private String username;
    private int jumlahObatA[];
    private int jumlahObatB[];
    private TimeSeriesCollection dataset = new TimeSeriesCollection();
    private TimeSeries series1 = new TimeSeries("Obat A");
    private TimeSeries series2 = new TimeSeries("Obat B");
    private TimeSeries series3 = new TimeSeries("Perkiraan Obat A");
    private TimeSeries series4 = new TimeSeries("Perkiraan Obat B");

    public c_prediksi(String username) throws SQLException {
        this.username = username;
        view = new v_prediksi();
        view.setLocationRelativeTo(null);
        try {
            modelH = new m_histori();
            modelO = new m_stok();
            modelP = new m_permintaan();
            view.setObat(modelO.getListObat());
            view.setNamaObat(modelO.getListNamaObat());
            view.kembaliButton().addActionListener(new kembali());
            view.obatAField().addActionListener(new obatA());
            view.obatBField().addActionListener(new obatB());
            view.namaObatAField().addActionListener(new namaObatA());
            view.namaObatBField().addActionListener(new namaObatB());
            view.prediksikanAButton().addActionListener(new prediksikanA());
            view.prediksikanBButton().addActionListener(new prediksikanB());
            view.masukkanAButton().addActionListener(new masukkanA());
            view.masukkanBButton().addActionListener(new masukkanB());
        } catch (Exception ex) {
            ex.printStackTrace();
            view.message("Koneksi ke database gagal");
            System.exit(0);
        }
    }

    private class kembali implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.dispose();
            new c_homeSupervisor(username);
        }
    }

    private class obatA implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.namaObatAField().setSelectedIndex(view.obatAField().getSelectedIndex());
                int permintaan[] = modelH.getPermintaanBulanan(view.getNomorObatA(), username);
                view.setValueObatA(permintaan);
                if (permintaan.length < 3) {
                    view.message("Data permintaan obat tidak lengkap untuk melakukan prediksi.");
                    view.prediksikanAButton().setEnabled(false);
                } else {
                    view.onA();
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_prediksi.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class obatB implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.namaObatBField().setSelectedIndex(view.obatBField().getSelectedIndex());
                int permintaan[] = modelH.getPermintaanBulanan(view.getNomorObatB(), username);
                view.setValueObatB(permintaan);
                if (permintaan.length < 3) {
                    view.message("Data permintaan obat tidak lengkap untuk melakukan prediksi.");
                    view.prediksikanBButton().setEnabled(false);
                } else {
                    view.onB();
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_prediksi.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class namaObatA implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.obatAField().setSelectedIndex(view.namaObatAField().getSelectedIndex());
        }
    }

    private class namaObatB implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.obatBField().setSelectedIndex(view.namaObatBField().getSelectedIndex());
        }
    }

    private class prediksikanA implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.chart(createDatasetA(modelH.getValueObat(view.getNomorObatA(), username)));
                view.masukkanAButton().setEnabled(true);
            } catch (Exception ex) {
                ex.printStackTrace();
                view.message("Data input invalid");
            }
            view.reset();
        }
    }

    private class prediksikanB implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                view.chart(createDatasetB(modelH.getValueObat(view.getNomorObatB(), username)));
                view.masukkanBButton().setEnabled(true);
            } catch (Exception ex) {
                ex.printStackTrace();
                view.message("Data input invalid");
            }
            view.reset();
        }
    }

    private class masukkanA implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (view.messageYesNo("Masukkan perdiksi berikut ke permintaan?"
                        + "\nNomor Obat : " + view.getNomorObatA()
                        + "\nNama Obat : " + modelO.getNamaObat(view.getNomorObatA())
                        + "\nJumlah Obat : " + jumlahObatA[0]) == 0) {
                    modelP.create(view.getNomorObatA(), jumlahObatA[0], username);
                    view.message("Permintaan telah dibuat");
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_prediksi.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class masukkanB implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (view.messageYesNo("Masukkan obat berikut ke penawaran?"
                        + "\nNomor Obat : " + view.getNomorObatB()
                        + "\nNama Obat : " + modelO.getNamaObat(view.getNomorObatB())
                        + "\nJumlah Obat : " + jumlahObatB[0]) == 0) {
                    modelP.create(view.getNomorObatB(), jumlahObatB[0], username);
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_prediksi.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private XYDataset createDatasetA(int valueObatA[][]) {
        series1.clear();
        for (int i = 0; i < valueObatA.length; i++) {
            series1.add(new Month(valueObatA[1][i], valueObatA[2][i]), valueObatA[0][i]);
        }

        series3.clear();
        series3.add(new Month(valueObatA[1][0], valueObatA[2][0]), valueObatA[0][0]);
        jumlahObatA = perkiraan(valueObatA[0]);
        for (int i = 0; i < jumlahObatA.length; i++) {
            if (valueObatA[1][0] + i + 1 <= 12) {
                series3.add(new Month(valueObatA[1][0] + i + 1, valueObatA[2][0]), jumlahObatA[i]);
            } else {
                series3.add(new Month((valueObatA[1][0] + i + 1) % 12, (valueObatA[2][0] + 1)), jumlahObatA[i]);
            }
        }
        dataset.removeAllSeries();
        dataset.addSeries(series1);
        dataset.addSeries(series2);
        dataset.addSeries(series3);
        dataset.addSeries(series4);

        return dataset;
    }

    private XYDataset createDatasetB(int valueObatB[][]) {
        series2.clear();
        for (int i = 0; i < valueObatB.length; i++) {
            series2.add(new Month(valueObatB[1][i], valueObatB[2][i]), valueObatB[0][i]);
        }

        series4.clear();
        series4.add(new Month(valueObatB[1][0], valueObatB[2][0]), valueObatB[0][0]);
        jumlahObatB = perkiraan(valueObatB[0]);
        for (int i = 0; i < jumlahObatB.length; i++) {
            if (valueObatB[1][0] + i + 1 <= 12) {
                series4.add(new Month(valueObatB[1][0] + i + 1, valueObatB[2][0]), jumlahObatB[i]);
            } else {
                series4.add(new Month((valueObatB[1][0] + i + 1) % 12, (valueObatB[2][0] + 1)), jumlahObatB[i]);
            }
        }
        dataset.removeAllSeries();
        dataset.addSeries(series1);
        dataset.addSeries(series2);
        dataset.addSeries(series3);
        dataset.addSeries(series4);

        return dataset;
    }

    private int[] perkiraan(int jumlah[]) {
        int[] data = new int[3];
        int hasil[] = new int[3];
        data = jumlah;
        hasil[0] = (data[0] * 1 + data[1] * 2 + data[2] * 3) / 6;
        hasil[1] = (data[1] * 1 + data[2] * 2 + hasil[0] * 3) / 6;
        hasil[2] = (data[2] * 1 + hasil[0] * 2 + hasil[1] * 3) / 6;
        return hasil;
    }
}
